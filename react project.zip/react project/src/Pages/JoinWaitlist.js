import React from "react";
import FormDetails from "../Components/WaitlistForm/Detailsform/Details";

const Join = () => {
  return(
      <React.Fragment>
          <FormDetails></FormDetails>
      </React.Fragment>
  );
};

export default Join;
